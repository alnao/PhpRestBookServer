	<?php
	/*METHOD POST AND PUT*/
	
	header("Access-Control-Allow-Credentials: true");
	header("Access-Control-Allow-Origin: *");
	header("Access-Control-Allow-Methods: GET, POST, PUT,DELETE, OPTIONS");
	header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, Authorization");
	require_once 'conn.php';
	
	$json = file_get_contents('php://input');
	
	$mypost = json_decode($json,true);
	$titolo = $mypost['titolo'];
	$autore = $mypost['autore'];
	$isbn = $mypost['isbn'];
	$prezzo = $mypost['prezzo'];
	$img = $mypost['img'];
	$trama = $mypost['trama'];
	
	if(isset ($_GET['id'])){
	$id = $_GET['id'];	
	try{
	$sql = "UPDATE book SET titolo= :titolo, 
            autore= :autore, 
            isbn= :isbn,  
            prezzo= :prezzo,  
            img= :img,
			trama= :trama
            WHERE id= :id";
$stmt = $dbh->prepare($sql);                                  
$stmt->bindParam(':titolo', $titolo);       
$stmt->bindParam(':autore', $autore);    
$stmt->bindParam(':isbn', $isbn); 
$stmt->bindParam(':prezzo', $prezzo); 
$stmt->bindParam(':img', $img);
$stmt->bindParam(':trama', $trama); 
$stmt->bindParam(':id', $id);   
$stmt->execute();
	}catch(PDOException $e) {
				echo $sql ."<br/>" . $e->getMessage();
	}
}
	
	else if($titolo){
		try {
			$sql = "INSERT INTO book (titolo,autore,isbn,prezzo,img,trama)
		VALUES('$titolo','$autore','$isbn', '$prezzo','$img','$trama')";
			$dbh->exec($sql);
		}catch(PDOException $e) {
			echo $sql ."<br/>" . $e->getMessage();
		}
	}
	

